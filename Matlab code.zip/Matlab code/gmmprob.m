function prob = gmmprob(mix, x)
%GMMPROB Computes the data probability for a Gaussian mixture model.
%
%	Description
%	 This function computes the unconditional data density P(X) for a
%	Gaussian mixture model.  The data structure MIX defines the mixture
%	model, while the matrix X contains the data vectors.  Each row of X
%	represents a single vector.
%
%	See also
%	GMM, GMMPOST, GMMACTIV
%

%	Copyright (c) Ian T Nabney (1996-2001)

% Check that inputs are consistent
errstring = consist(mix, 'gmm', x);
if ~isempty(errstring)
  error(errstring);
end

% Compute activations
a = gmmactiv(mix, x);

% Form dot product with priors
%modified by gxf
%prob = a * (mix.priors)';

LogPxGc = a;
LogPxc = LogPxGc + ones(size(LogPxGc,1),1) * log(mix.priors + realmin);
LogPxc = LogPxc';
Q = LogPxc - repmat(max(LogPxc,[],1),mix.ncentres,1);
Q = exp(Q)+realmin;
prob = sum(Q',2); 
