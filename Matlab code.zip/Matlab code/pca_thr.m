function [contributions] = pca_thr(X,sigma,P1,thr,K)
% gui中求贡献度
X = X';
[N,D]=size(X);
%距离矩阵W
W=zeros(N,N);
for i=1:N
    for j=1:N
        W(i,j)=norm(X(i,:)-X(j,:));
    end
end

if D==3
%求贡献度
contributions = zeros(N,1);
for i=1:N
    point = zeros(N,1);
    for j=1:N
        if W(i,j)<=sigma
            point(j)=1;
        end
    end
    % sigma 距离内的点存入neighbor
    number=sum(point~=0);
    [~,index]=sort(point,1,'descend');
    neighbor = zeros(number,3);
    for ii=1:number
       for jj=1:3
           neighbor(ii,jj)=X(index(ii),jj);
       end
    end
    % 对neighbor内的点求特征值
    covariance=cov(neighbor);
    [V,diag_value]=eig(covariance);
     diagnoal=diag(diag_value);
    % 对特征值进行降序
    [values,~]=sort(diagnoal,1,'descend');
    sum1=0.0;
    sum2=0.0;
    for s=1:P1
        sum1 = sum1+values(s);
    end
    for z=1:D
        sum2 = sum2+values(z);
    end
    contribution = sum1/sum2;
    contributions(i,1)=contribution;
end

elseif D==2
     contributions = zeros(N,1);
for i=1:N
    point = zeros(N,1);
    for j=1:N
        if W(i,j)<=sigma
            point(j)=1;
        end
    end
    % sigma 距离内的点存入neighbor
    number=sum(point~=0);
    [~,index]=sort(point,1,'descend');
    neighbor = zeros(number,2);
    for ii=1:number
       for jj=1:2
           neighbor(ii,jj)=X(index(ii),jj);
       end
    end
    % 对neighbor内的点求特征值
    covariance=cov(neighbor);
    [V,diag_value]=eig(covariance);
     diagnoal=diag(diag_value);
    % 对特征值进行降序
    [values,index]=sort(diagnoal,1,'descend');
    sum1=0.0;
    sum2=0.0;
    for s=1:P1
        sum1 = sum1+values(s);
    end
    for z=1:D
        sum2 = sum2+values(z);
    end
    contribution = sum1/sum2;
    contributions(i,1)=contribution;
end
end

