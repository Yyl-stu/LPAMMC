function D=knnsearch(K,DD,sigma2)

N = size(DD,2);
D = zeros(N,N);
[dist,ind]=sort(DD);% 对每�?��进行升序排列

for i=1:N
    D(i,ind((2:K+1),i))=exp(-DD(i,ind((2:K+1),i))/(sigma2*sigma2));
end
