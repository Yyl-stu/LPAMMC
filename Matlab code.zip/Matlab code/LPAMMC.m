% -------------------------------------------------------------------------
%Aim:
%The matlab code of "Label Propagation Algorithm for Intersecting Multimanifolds"
% -------------------------------------------------------------------------
%Input:
%     X              N*D
%     true_labels    N*1
%  Intersection Region Identification Parameters
%     sigma      spherical neighborhood
%     P1         first P1 dimensions
%     thr        Eigenvalue cut-off threshold
%  Label propagation parameters
%     dd         Number of label propagation iterations
%     K          K-nearest neighbor size constructed for each point
%     sigma2     Distance matrix bandwidth
%     similar    Tangent space similarity
%     C          Number of clusters
%     label_index  Mark point index eg: [1; 4; 701] Mark point 1, 4,701
%  MPPCA model parameters
%     ppca_dim    subdimension
%     ncentres    number of centers
% -------------------------------------------------------------------------
%Output:
%	  prelabel: Clustering results
%	  new_X: point of intersection
%	  row： index of intersection point
%	  ppca_labels：The label of the split block
% -------------------------------------------------------------------------
% Written by YuLiang Yuan
% School of Computer and Information Technology, Shanxi University
% July 2022



function [prelabel,new_X,row,ppca_labels] = LPAMMC(X,sigma,P1,thr,dd,K,similar,C,sigma2,label_index,ppca_dim,ncentres)

[N,D]=size(X);
DD = pdist2(X,X,'euclidean');
[new_X,row] = findIntersectionArea(X,DD,sigma,P1,thr);
[new_N,~] = size(new_X);

% 把new_X传入MPPCA分块
[ppca_label,UU] = MPPCA(new_X',ppca_dim,ncentres);
ppca_labels=ppca_label';


% 计算点的K近邻，形成连接矩阵T
T=knnsearch(K,DD,sigma2);

[tempI,tempJ] = find(UU<similar);
for tt = 1:length(tempI)
    tI = row(find(ppca_labels==tempI(tt)));
    tJ = row(find(ppca_labels==tempJ(tt)));
    T(tI,tJ)=0;
    T(tJ,tI)=0;
end
disp(sum(sum(T~=0)));

% 标签传播
[prelabel] = LPA(T,label_index,N,C,dd);

