function varargout = main(varargin)
% MAIN MATLAB code for main.fig
%      MAIN, by itself, creates a new MAIN or raises the existing
%      singleton*.
%
%      H = MAIN returns the handle to a new MAIN or the handle to
%      the existing singleton*.
%
%      MAIN('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MAIN.M with the given input arguments.
%
%      MAIN('Property','Value',...) creates a new MAIN or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before main_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to main_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help main

% Last Modified by GUIDE v2.5 25-Dec-2021 17:10:48

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @main_OpeningFcn, ...
                   'gui_OutputFcn',  @main_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before main is made visible.
function main_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to main (see VARARGIN)

% Choose default command line output for main
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes main wait for user response (see UIRESUME)
% uiwait(handles.figure1);

    axes(handles.axes2); %指定需要清空的坐标轴
    cla reset;
    set(handles.axes2,'Visible','off');
    
    axes(handles.axes3); %指定需要清空的坐标轴
    cla reset;
    set(handles.axes3,'Visible','off');
    
    axes(handles.axes4); %指定需要清空的坐标轴
    cla reset;
    set(handles.axes4,'Visible','off'); 
    
    axes(handles.axes5); %指定需要清空的坐标轴
    cla reset;
    set(handles.axes5,'Visible','off');
    
    set(handles.printbk,'Visible','off');

    
% --- Outputs from this function are returned to the command line.
function varargout = main_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in loadMatrix.
function loadMatrix_Callback(hObject, eventdata, handles)
% hObject    handle to loadMatrix (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename,pathname]=uigetfile('*.mat','M-matrix (*.mat)','选择mat数据集');
str=strcat(pathname,filename);
set(handles.writeMatrix,'String',filename);
M=load(str);
global X;
global S;
global Filename;
Filename=filename;
if strcmp(filename,'X1500.mat') || strcmp(filename,'two_spirals.mat') || strcmp(filename,'three_linear_planes.mat')||strcmp(filename,'');   
    axes(handles.axes2); %指定需要清空的坐标轴
    cla reset;
    set(handles.axes2,'Visible','off');
    
    axes(handles.axes3); %指定需要清空的坐标轴
    cla reset;
    set(handles.axes3,'Visible','off');
    
    axes(handles.axes4); %指定需要清空的坐标轴
    cla reset;
    set(handles.axes4,'Visible','off');
    
    axes(handles.axes5); %指定需要清空的坐标轴
    cla reset;
    set(handles.axes5,'Visible','off');
    
    set(handles.writeMatrix,'String',filename);
    set(handles.datatable1,'Data',[]);
    set(handles.datatable2,'Data',[]);
    set(handles.datatable3,'Data',[]);
    set(handles.acc,'String',[]);
    
    set(handles.printbk,'Visible','off');
    X=M.X;
    S=M.true_labels';
    show1 (hObject, eventdata, handles,X);
else
    set(handles.writeMatrix,'String',filename);
    set(handles.datatable1,'Data',[]);
    set(handles.datatable2,'Data',[]);
    set(handles.datatable3,'Data',[]);
    X=M.fea';
    S=M.gnd';
    axes(handles.axes2); %指定需要清空的坐标轴
    cla reset;
    set(handles.axes2,'Visible','off');
    
    axes(handles.axes3); %指定需要清空的坐标轴
    cla reset;
    set(handles.axes3,'Visible','off');
    
    axes(handles.axes4); %指定需要清空的坐标轴
    cla reset;
    set(handles.axes4,'Visible','off');
    
    axes(handles.axes5); %指定需要清空的坐标轴
    cla reset;
    set(handles.axes5,'Visible','off');
    set(handles.acc,'String',[]);

    set(handles.printbk,'Visible','on');

    set(handles.print2,'String',[]);
    set(handles.print3,'String',[]);

end

%------显示人造数据集原始图像
function show1 (hObject, eventdata, handles,X)
[row,col]=size(X);
axes(handles.axes2);
rotate3d on;
if row==2
    plot(X(1,:),X(2,:),'.');
elseif row==3
    plot3(X(1,:),X(2,:),X(3,:),'.');
else

end

% 根据阈值画图
function show2 (hObject, eventdata, handles,X,thr,contributions)
[D,N]=size(X);
axes(handles.axes3);
rotate3d on;
if D==2
    plot(X(1,:),X(2,:),'.');
    hold on
    for i=1:N
         if (contributions(i)<thr)
            plot(X(1,i),X(2,i),'og')    
         end
    end
    hold off   
elseif D==3
    plot3(X(1,:),X(2,:),X(3,:),'.');
    hold on
    for i=1:N
         if (contributions(i)<thr)
            plot3(X(1,i),X(2,i),X(3,i),'og')
         end
    end
    hold off
else
    G=imread('1.jpg');
    axes(handles.axes1);
    imshow(G);
end

% 根据MPPCA标签画图
function show3 (hObject, eventdata, handles,new_X,ppca_labels)
% new_X 为N*D
[N,D]=size(new_X);
axes(handles.axes4);
rotate3d on;
if D ==2
    plot(new_X(:,1),new_X(:,2),'.')%画出全部样本的分布点
    hold on
    for i=1:N
        if ppca_labels(i) ==1
            plot(new_X(i,1),new_X(i,2),'.r');
        elseif ppca_labels(i) ==2
            plot(new_X(i,1),new_X(i,2),'.g');
        elseif ppca_labels(i) ==3
            plot(new_X(i,1),new_X(i,2),'.b');
        elseif ppca_labels(i) ==4
            plot(new_X(i,1),new_X(i,2),'.c');
        elseif ppca_labels(i) ==5
            plot(new_X(i,1),new_X(i,2),'.m');
        elseif ppca_labels(i) ==6
            plot(new_X(i,1),new_X(i,2),'dr');
        elseif ppca_labels(i) ==7
            plot(new_X(i,1),new_X(i,2),'dg');
        elseif ppca_labels(i) ==8
            plot(new_X(i,1),new_X(i,2),'db');
        elseif ppca_labels(i) ==9
            plot(new_X(i,1),new_X(i,2),'dc');
        elseif ppca_labels(i) ==10
            plot(new_X(i,1),new_X(i,2),'dm');
        elseif ppca_labels(i) ==11
           plot(new_X(i,1),new_X(i,2),'+r');
        elseif ppca_labels(i) ==12
            plot(new_X(i,1),new_X(i,2),'+g');
        elseif ppca_labels(i) ==13
            plot(new_X(i,1),new_X(i,2),'+b');
        elseif ppca_labels(i) ==14
            plot(new_X(i,1),new_X(i,2),'+c');
        elseif ppca_labels(i) ==15
            plot(new_X(i,1),new_X(i,2),'+m');
        elseif ppca_labels(i) ==16
            plot(new_X(i,1),new_X(i,2),'*r');
        elseif ppca_labels(i) ==17
            plot(new_X(i,1),new_X(i,2),'*g');
        elseif ppca_labels(i) ==18
            plot(new_X(i,1),new_X(i,2),'*b');
        elseif ppca_labels(i) ==19
            plot(new_X(i,1),new_X(i,2),'*c');
        elseif ppca_labels(i) ==20
            plot(new_X(i,1),new_X(i,2),'*m');
        elseif ppca_labels(i) ==21
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'or');
        elseif ppca_labels(i) ==22
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'og');
        elseif ppca_labels(i) ==23
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'ob');
        elseif ppca_labels(i) ==24
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'oc');
        elseif ppca_labels(i) ==25
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'om');
        elseif ppca_labels(i) ==26
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'pr');
        elseif ppca_labels(i) ==27
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'pg');
        elseif ppca_labels(i) ==28
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'pb');
        elseif ppca_labels(i) ==29
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'pc');
        elseif ppca_labels(i) ==30
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'pm');
        elseif ppca_labels(i) ==31
            plot(new_X(i,1),new_X(i,2),'sr');
        elseif ppca_labels(i) ==32
            plot(new_X(i,1),new_X(i,2),'sg');
        elseif ppca_labels(i) ==33
            plot(new_X(i,1),new_X(i,2),'sb');
        elseif ppca_labels(i) ==34
            plot(new_X(i,1),new_X(i,2),'sc');
        elseif ppca_labels(i) ==35
            plot(new_X(i,1),new_X(i,2),'sm');
        elseif ppca_labels(i) ==36
            plot(new_X(i,1),new_X(i,2),'hr');
        elseif ppca_labels(i) ==37
            plot(new_X(i,1),new_X(i,2),'hg');
        elseif ppca_labels(i) ==38
            plot(new_X(i,1),new_X(i,2),'hb');
        elseif ppca_labels(i) ==39
            plot(new_X(i,1),new_X(i,2),'hc');
        elseif ppca_labels(i) ==40
            plot(new_X(i,1),new_X(i,2),'hm');
        elseif ppca_labels(i) ==41
           plot(new_X(i,1),new_X(i,2),'xr');
        elseif ppca_labels(i) ==42
            plot(new_X(i,1),new_X(i,2),'xg');
        elseif ppca_labels(i) ==43
            plot(new_X(i,1),new_X(i,2),'xb');
        elseif ppca_labels(i) ==44
            plot(new_X(i,1),new_X(i,2),'xc');
        elseif ppca_labels(i) ==45
            plot(new_X(i,1),new_X(i,2),'xm');
        elseif ppca_labels(i) ==46
            plot(new_X(i,1),new_X(i,2),'<r');
        elseif ppca_labels(i) ==47
            plot(new_X(i,1),new_X(i,2),'<g');
        elseif ppca_labels(i) ==48
            plot(new_X(i,1),new_X(i,2),'<b');
        elseif ppca_labels(i) ==49
            plot(new_X(i,1),new_X(i,2),'<c');
        elseif ppca_labels(i) ==50
            plot(new_X(i,1),new_X(i,2),'<m');
        elseif ppca_labels(i) ==51
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'>r');
        elseif ppca_labels(i) ==52
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'>g');
        elseif ppca_labels(i) ==53
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'>b');
        elseif ppca_labels(i) ==54
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'>c');
        elseif ppca_labels(i) ==55
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'>m');
        elseif ppca_labels(i) ==56
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'^r');
        elseif ppca_labels(i) ==57
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'^g');
        elseif ppca_labels(i) ==58
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'^b');
        elseif ppca_labels(i) ==59
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'^c');
        elseif ppca_labels(i) ==60
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'^m');
        elseif ppca_labels(i) ==61
            plot(new_X(i,1),new_X(i,2),'.r');
        elseif ppca_labels(i) ==62
            plot(new_X(i,1),new_X(i,2),'.g');
        elseif ppca_labels(i) ==63
            plot(new_X(i,1),new_X(i,2),'.b');
        elseif ppca_labels(i) ==64
            plot(new_X(i,1),new_X(i,2),'.c');
        elseif ppca_labels(i) ==65
            plot(new_X(i,1),new_X(i,2),'.m');
        elseif ppca_labels(i) ==66
            plot(new_X(i,1),new_X(i,2),'dr');
        elseif ppca_labels(i) ==67
            plot(new_X(i,1),new_X(i,2),'dg');
        elseif ppca_labels(i) ==68
            plot(new_X(i,1),new_X(i,2),'db');
        elseif ppca_labels(i) ==69
            plot(new_X(i,1),new_X(i,2),'dc');
        elseif ppca_labels(i) ==70
            plot(new_X(i,1),new_X(i,2),'dm');
        elseif ppca_labels(i) ==71
           plot(new_X(i,1),new_X(i,2),'+r');
        elseif ppca_labels(i) ==72
            plot(new_X(i,1),new_X(i,2),'+g');
        elseif ppca_labels(i) ==73
            plot(new_X(i,1),new_X(i,2),'+b');
        elseif ppca_labels(i) ==74
            plot(new_X(i,1),new_X(i,2),'+c');
        elseif ppca_labels(i) ==75
            plot(new_X(i,1),new_X(i,2),'+m');
        elseif ppca_labels(i) ==76
            plot(new_X(i,1),new_X(i,2),'*r');
        elseif ppca_labels(i) ==77
            plot(new_X(i,1),new_X(i,2),'*g');
        elseif ppca_labels(i) ==78
            plot(new_X(i,1),new_X(i,2),'*b');
        elseif ppca_labels(i) ==79
            plot(new_X(i,1),new_X(i,2),'*c');
        elseif ppca_labels(i) ==80
            plot(new_X(i,1),new_X(i,2),'*m');
        elseif ppca_labels(i) ==81
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'or');
        elseif ppca_labels(i) ==82
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'og');
        elseif ppca_labels(i) ==83
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'ob');
        elseif ppca_labels(i) ==84
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'oc');
        elseif ppca_labels(i) ==85
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'om');
        elseif ppca_labels(i) ==86
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'pr');
        elseif ppca_labels(i) ==87
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'pg');
        elseif ppca_labels(i) ==88
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'pb');
        elseif ppca_labels(i) ==89
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'pc');
        elseif ppca_labels(i) ==90
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'pm'); 
        elseif ppca_labels(i) ==91
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'or');
        elseif ppca_labels(i) ==92
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'og');
        elseif ppca_labels(i) ==93
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'ob');
        elseif ppca_labels(i) ==94
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'oc');
        elseif ppca_labels(i) ==95
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'om');
        elseif ppca_labels(i) ==96
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'pr');
        elseif ppca_labels(i) ==97
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'pg');
        elseif ppca_labels(i) ==98
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'pb');
        elseif ppca_labels(i) ==99
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'pc');
        elseif ppca_labels(i) ==100
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'pm');            
        end
    end
elseif  D ==3
    plot3(new_X(:,1),new_X(:,2),new_X(:,3),'.');%画出全部样本的分布点
    hold on
    for i=1:N
    if ppca_labels(i) ==1
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'.r');
        elseif ppca_labels(i) ==2
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'.g');
        elseif ppca_labels(i) ==3
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'.b');
        elseif ppca_labels(i) ==4
        	plot3(new_X(i,1),new_X(i,2),new_X(i,3),'.c');
        elseif ppca_labels(i) ==5
        	plot3(new_X(i,1),new_X(i,2),new_X(i,3),'.m');
        elseif ppca_labels(i) ==6
        	plot3(new_X(i,1),new_X(i,2),new_X(i,3),'dr');
        elseif ppca_labels(i) ==7
        	plot3(new_X(i,1),new_X(i,2),new_X(i,3),'dg');
        elseif ppca_labels(i) ==8
        	plot3(new_X(i,1),new_X(i,2),new_X(i,3),'db');
        elseif ppca_labels(i) ==9
        	plot3(new_X(i,1),new_X(i,2),new_X(i,3),'dc');
        elseif ppca_labels(i) ==10
        	plot3(new_X(i,1),new_X(i,2),new_X(i,3),'dm');
        elseif ppca_labels(i) ==11
        	plot3(new_X(i,1),new_X(i,2),new_X(i,3),'+r');
        elseif ppca_labels(i) ==12
        	plot3(new_X(i,1),new_X(i,2),new_X(i,3),'+g');
        elseif ppca_labels(i) ==13
        	plot3(new_X(i,1),new_X(i,2),new_X(i,3),'+b');
        elseif ppca_labels(i) ==14
        	plot3(new_X(i,1),new_X(i,2),new_X(i,3),'+c');
        elseif ppca_labels(i) ==15
        	plot3(new_X(i,1),new_X(i,2),new_X(i,3),'+m');
        elseif ppca_labels(i) ==16
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'*r');
        elseif ppca_labels(i) ==17
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'*g');
        elseif ppca_labels(i) ==18
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'*b');
        elseif ppca_labels(i) ==19
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'*c');
        elseif ppca_labels(i) ==20
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'*m');
        elseif ppca_labels(i) ==21
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'or');
        elseif ppca_labels(i) ==22
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'og');
        elseif ppca_labels(i) ==23
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'ob');
        elseif ppca_labels(i) ==24
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'oc');
        elseif ppca_labels(i) ==25
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'om');
        elseif ppca_labels(i) ==26
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'pr');
        elseif ppca_labels(i) ==27
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'pg');
        elseif ppca_labels(i) ==28
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'pb');
        elseif ppca_labels(i) ==29
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'pc');
        elseif ppca_labels(i) ==30
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'pm');
        elseif ppca_labels(i) ==31
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'sr');
        elseif ppca_labels(i) ==32
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'sg');
        elseif ppca_labels(i) ==33
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'sb');
        elseif ppca_labels(i) ==34
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'sc');
        elseif ppca_labels(i) ==35
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'sm');
        elseif ppca_labels(i) ==36
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'hr');
        elseif ppca_labels(i) ==37
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'hg');
        elseif ppca_labels(i) ==38
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'hb');
        elseif ppca_labels(i) ==39
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'hc');
        elseif ppca_labels(i) ==40
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'hm');
        elseif ppca_labels(i) ==41
           plot3(new_X(i,1),new_X(i,2),new_X(i,3),'xr');
        elseif ppca_labels(i) ==42
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'xg');
        elseif ppca_labels(i) ==43
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'xb');
        elseif ppca_labels(i) ==44
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'xc');
        elseif ppca_labels(i) ==45
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'xm');
        elseif ppca_labels(i) ==46
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'<r');
        elseif ppca_labels(i) ==47
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'<g');
        elseif ppca_labels(i) ==48
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'<b');
        elseif ppca_labels(i) ==49
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'<c');
        elseif ppca_labels(i) ==50
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'<m');
        elseif ppca_labels(i) ==51
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'>r');
        elseif ppca_labels(i) ==52
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'>g');
        elseif ppca_labels(i) ==53
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'>b');
        elseif ppca_labels(i) ==54
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'>c');
        elseif ppca_labels(i) ==55
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'>m');
        elseif ppca_labels(i) ==56
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'^r');
        elseif ppca_labels(i) ==57
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'^g');
        elseif ppca_labels(i) ==58
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'^b');
        elseif ppca_labels(i) ==59
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'^c');
        elseif ppca_labels(i) ==60
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'^m');
        elseif ppca_labels(i) ==61
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'.r');
        elseif ppca_labels(i) ==62
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'.g');
        elseif ppca_labels(i) ==63
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'.b');
        elseif ppca_labels(i) ==64
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'.c');
        elseif ppca_labels(i) ==65
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'.m');
        elseif ppca_labels(i) ==66
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'dr');
        elseif ppca_labels(i) ==67
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'dg');
        elseif ppca_labels(i) ==68
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'db');
        elseif ppca_labels(i) ==69
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'dc');
        elseif ppca_labels(i) ==70
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'dm');
        elseif ppca_labels(i) ==71
           plot3(new_X(i,1),new_X(i,2),new_X(i,3),'+r');
        elseif ppca_labels(i) ==72
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'+g');
        elseif ppca_labels(i) ==73
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'+b');
        elseif ppca_labels(i) ==74
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'+c');
        elseif ppca_labels(i) ==75
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'+m');
        elseif ppca_labels(i) ==76
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'*r');
        elseif ppca_labels(i) ==77
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'*g');
        elseif ppca_labels(i) ==78
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'*b');
        elseif ppca_labels(i) ==79
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'*c');
        elseif ppca_labels(i) ==80
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'*m');
        elseif ppca_labels(i) ==81
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'or');
        elseif ppca_labels(i) ==82
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'og');
        elseif ppca_labels(i) ==83
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'ob');
        elseif ppca_labels(i) ==84
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'oc');
        elseif ppca_labels(i) ==85
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'om');
        elseif ppca_labels(i) ==86
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'pr');
        elseif ppca_labels(i) ==87
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'pg');
        elseif ppca_labels(i) ==88
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'pb');
        elseif ppca_labels(i) ==89
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'pc');
        elseif ppca_labels(i) ==90
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'pm'); 
        elseif ppca_labels(i) ==91
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'or');
        elseif ppca_labels(i) ==92
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'og');
        elseif ppca_labels(i) ==93
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'ob');
        elseif ppca_labels(i) ==94
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'oc');
        elseif ppca_labels(i) ==95
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'om');
        elseif ppca_labels(i) ==96
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'pr');
        elseif ppca_labels(i) ==97
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'pg');
        elseif ppca_labels(i) ==98
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'pb');
        elseif ppca_labels(i) ==99
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'pc');
        elseif ppca_labels(i) ==100
            plot3(new_X(i,1),new_X(i,2),new_X(i,3),'pm');            
    end
    end
    hold off 
end


function writeMatrix_Callback(hObject, eventdata, handles)
% hObject    handle to writeMatrix (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of writeMatrix as text
%        str2double(get(hObject,'String')) returns contents of writeMatrix as a double


% --- Executes during object creation, after setting all properties.
function writeMatrix_CreateFcn(hObject, eventdata, handles)
% hObject    handle to writeMatrix (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in defaults.
% 默认参数
function defaults_Callback(hObject, eventdata, handles)
% hObject    handle to defaults (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Filename;
global Sigma;
global P1;
global Thr;
global K;
global ppca_dim;
global ncentres;
global knn;
global power;
global C;
global Similar;
global Iter;
set(handles.datatable1,'Data',[]);
set(handles.datatable2,'Data',[]);
set(handles.datatable3,'Data',[]);
set(handles.acc,'String',[]);
if strcmp(Filename,'X1500.mat')
    newArray1 = {10, 2, 0.94, 30}; %保存在新的矩阵中
    newArray2 = {2, 100, 7, 8}; 
    newArray3 = {2, 0.7, 100}; 
    set(handles.datatable1,'Data',newArray1);  %显示到表格中
    set(handles.datatable2,'Data',newArray2);
    set(handles.datatable3,'Data',newArray3);
elseif strcmp(Filename,'two_spirals.mat')
    newArray1 = {0.3, 1, 0.6, 20}; %保存在新的矩阵中
    newArray2 = {1, 8, 10, 8}; 
    newArray3 = {2, 0.7, 60}; 
    set(handles.datatable1,'Data',newArray1);  %显示到表格中
    set(handles.datatable2,'Data',newArray2);
    set(handles.datatable3,'Data',newArray3);
elseif strcmp(Filename,'three_linear_planes.mat')
    newArray1 = {0.4, 2, 0.92, 15}; %保存在新的矩阵中
    newArray2 = {2, 8, 10, 8}; 
    newArray3 = {3, 0.9, 15}; 
    set(handles.datatable1,'Data',newArray1);  %显示到表格中
    set(handles.datatable2,'Data',newArray2);
    set(handles.datatable3,'Data',newArray3);
elseif strcmp(Filename,'COIL20_32.mat')
    newArray1 = {10, 30, 0.94,30}; %保存在新的矩阵中
    newArray2 = {1023, 20, 6, 8}; 
    newArray3 = {20, 0.7,4}; 
    set(handles.datatable1,'Data',newArray1);  %显示到表格中
    set(handles.datatable2,'Data',newArray2);
    set(handles.datatable3,'Data',newArray3);
elseif strcmp(Filename,'umist_cropped.mat')
    newArray1 = {1200, 12, 0.92, 30}; %保存在新的矩阵中
    newArray2 = {60, 40, 4, 7}; 
    newArray3 = {40, 0.8, 5}; 
    set(handles.datatable1,'Data',newArray1);  %显示到表格中
    set(handles.datatable2,'Data',newArray2);
    set(handles.datatable3,'Data',newArray3);   
end
    Sigma = newArray1{1};
    P1 = newArray1{2};
    Thr = newArray1{3};
    K = newArray1{4};
    ppca_dim = newArray2{1};
    ncentres = newArray2{2};
    knn = newArray2{3};
    power = newArray2{4};
    C = newArray3{1};
    Similar = newArray3{2};
    Iter = newArray3{3};
    
% --- Executes on button press in runLPA.
function runLPA_Callback(hObject, eventdata, handles)
% hObject    handle to runLPA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if strcmp(Filename,'X1500.mat')
   

elseif strcmp(Filename,'two_spirals.mat')
    
elseif strcmp(Filename,'three_linear_planes.mat')
   
elseif strcmp(Filename,'COIL20_32.mat')
    
elseif strcmp(Filename,'umist_cropped.mat')
    
end


% --- Executes on button press in runMPPCA_LPA.
function runMPPCA_LPA_Callback(hObject, eventdata, handles)
% hObject    handle to runMPPCA_LPA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Filename;
global Sigma;
global P1;
global Thr;
global K;
global ppca_dim;
global ncentres;
global knn;
global power;
global C;
global Similar;
global Iter;
if strcmp(Filename,'X1500.mat')
   [Labelnews,X,N,ac] = run_X1500(Filename,Sigma,P1,Thr,K,ppca_dim,ncentres,knn,power,C,Similar,Iter);
   axes(handles.axes5);
   rotate3d on;
   plot3(X(1:N,1),X(1:N,2),X(1:N,3),'.')
   hold on
   for i=1:N
       if Labelnews(i)==1
           plot3(X(i,1),X(i,2),X(i,3),'og');
       elseif Labelnews(i)==2
           plot3(X(i,1),X(i,2),X(i,3),'or');
       end
   end
   hold off
elseif strcmp(Filename,'two_spirals.mat')
    [Labelnews,X,N,ac] = run_two_spirals(Filename,Sigma,P1,Thr,K,ppca_dim,ncentres,knn,power,C,Similar,Iter);
    axes(handles.axes5);
    rotate3d on;
    plot(X(1:N,1),X(1:N,2),'.')
    hold on
    for i=1:N
        if Labelnews(i)==1
            plot(X(i,1),X(i,2),'og');
        elseif Labelnews(i)==2
            plot(X(i,1),X(i,2),'or');
        end
    end
    hold off  
elseif strcmp(Filename,'three_linear_planes.mat')
	[Labelnews,X,N,ac] = run_three_linear_planes(Filename,Sigma,P1,Thr,K,ppca_dim,ncentres,knn,power,C,Similar,Iter);
	axes(handles.axes5);
    rotate3d on;
    plot3(X(1:N,1),X(1:N,2),X(1:N,3),'.')
    hold on
    for i=1:N
        if Labelnews(i)==1
            plot3(X(i,1),X(i,2),X(i,3),'og');
        elseif Labelnews(i)==2
            plot3(X(i,1),X(i,2),X(i,3),'or');
        elseif Labelnews(i)==3
            plot3(X(i,1),X(i,2),X(i,3),'om');
        end
    end
    hold off
elseif strcmp(Filename,'COIL20_32.mat')
    set(handles.print2,'String','用时：');
    [ac,time] = run_coil20_32(Filename,Sigma,P1,Thr,K,ppca_dim,ncentres,knn,power,C,Similar,Iter); 
    
    set(handles.print3,'String',time);
elseif strcmp(Filename,'umist_cropped.mat')
    set(handles.print2,'String','用时：');
    [ac,time] = run_umist_cropped(Filename,Sigma,P1,Thr,K,ppca_dim,ncentres,knn,power,C,Similar,Iter);
    
    set(handles.print3,'String',time);
end
set(handles.acc,'String',ac);

% --- Executes on button press in draw1.
% PCA 画图按钮
function draw1_Callback(hObject, eventdata, handles)
% hObject    handle to draw1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    global X
    global contributions
    global thr
    a = get(handles.datatable1,'Data');
    sigma = a{1,1};
    P1 = a{1,2};
    thr = a{1,3};
    K = a{1,4};
    contributions = pca_thr(X,sigma,P1,thr,K);   
    show2 (hObject, eventdata, handles,X,thr,contributions);
    
% --- Executes on button press in draw2.
% MPPCA 画图按钮
function draw2_Callback(hObject, eventdata, handles)
% hObject    handle to draw2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    global X
    global contributions
    global new_X
    global UU
    global ppca_labels
    global thr
    [N,D]=size(X');
    b = get(handles.datatable2,'Data');
    ppca_dim = b{1,1};
    ncentres = b{1,2};
    knn = b{1,3};
    power = b{1,4}; 
    % 低于阈值的为相交点，把相交点提取出来存入new_X
    temp=zeros(N,1);
    for i =1:N
        if contributions(i)<=thr
            temp(i,1)=i;
        end   
    end
    [row,~]=find(temp>0);
    [new_N,~]=size(row);
    new_X = zeros(new_N,D);
    if D ==3
        for i=1:new_N
            new_X(i,1)=X(1,row(i));
            new_X(i,2)=X(2,row(i));
            new_X(i,3)=X(3,row(i));
        end
    elseif D==2
        for i=1:new_N
            new_X(i,1)=X(1,row(i));
            new_X(i,2)=X(2,row(i));
        end
    end
    [ppca_label,UU,~,~,~] = MPPCA(new_X',ppca_dim,ncentres,knn,power);
    ppca_labels=ppca_label';
    show3 (hObject, eventdata, handles,new_X,ppca_labels);




% --- Executes on button press in add1.
function add1_Callback(hObject, eventdata, handles)
% hObject    handle to add1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Sigma;
global P1;
global Thr;
global K;
prompt ={'Sigma','P1','thr','K'}; %对话框内容提示
title = '请输入PCA参数';  %对话框标题
lines = [1,1,1,1]; %设置输入框行数
def = { '0','0','0','0'}; %默认值
tab = inputdlg(prompt,title,lines,def);  %对话框设置
Sigma = str2num(tab{1});  %对话框第一行内容
P1 = str2num(tab{2});
Thr = str2num(tab{3});
K = str2num(tab{4});
newArray = {Sigma,P1,Thr,K}; %保存在新的矩阵中
PCANEW = [newArray];  %新的数据源;
set(handles.datatable1,'Data',PCANEW);  %显示到表格中

% --- Executes on button press in add2.
function add2_Callback(hObject, eventdata, handles)
% hObject    handle to add2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global ppca_dim;
global ncentres;
global knn;
global power;
prompt ={'ppca_dim','ncentres','knn','power'}; %对话框内容提示
title = '请输入MPPCA参数';  %对话框标题
lines = [1,1,1,1]; %设置输入框行数
def = { '0','0','0','0'}; %默认值
tab = inputdlg(prompt,title,lines,def);  %对话框设置
ppca_dim = str2num(tab{1});  %对话框第一行内容
ncentres = str2num(tab{2});
knn = str2num(tab{3});
power = str2num(tab{4});
newArray = {ppca_dim,ncentres,knn,power}; %保存在新的矩阵中
MPPCANEW = [newArray];  %新的数据源;
set(handles.datatable2,'Data',MPPCANEW);  %显示到表格中


% --- Executes on button press in add3.
function add3_Callback(hObject, eventdata, handles)
% hObject    handle to add3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global C;
global Similar;
global Iter;

prompt ={'C','Similar','Iter'}; %对话框内容提示
title = '请输入传播参数';  %对话框标题
lines = [1,1,1]; %设置输入框行数
def = { '0','0','0'}; %默认值
tab = inputdlg(prompt,title,lines,def);  %对话框设置
C = str2num(tab{1});  %对话框第一行内容
Similar = str2num(tab{2});
Iter = str2num(tab{3});
newArray = {C,Similar,Iter}; %保存在新的矩阵中
juleiNEW = [newArray];  %新的数据源;
set(handles.datatable3,'Data',juleiNEW);  %显示到表格中



function acc_Callback(hObject, eventdata, handles)
% hObject    handle to acc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of acc as text
%        str2double(get(hObject,'String')) returns contents of acc as a double


% --- Executes during object creation, after setting all properties.
function acc_CreateFcn(hObject, eventdata, handles)
% hObject    handle to acc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function print_Callback(hObject, eventdata, handles)
% hObject    handle to print (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of print as text
%        str2double(get(hObject,'String')) returns contents of print as a double


% --- Executes during object creation, after setting all properties.
function print_CreateFcn(hObject, eventdata, handles)
% hObject    handle to print (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to print (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of print as text
%        str2double(get(hObject,'String')) returns contents of print as a double


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to print (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function print2_Callback(hObject, eventdata, handles)
% hObject    handle to print2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of print2 as text
%        str2double(get(hObject,'String')) returns contents of print2 as a double


% --- Executes during object creation, after setting all properties.
function print2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to print2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function print3_Callback(hObject, eventdata, handles)
% hObject    handle to print3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of print3 as text
%        str2double(get(hObject,'String')) returns contents of print3 as a double


% --- Executes during object creation, after setting all properties.
function print3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to print3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
